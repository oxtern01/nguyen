/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ASM;
import java.io.Serializable;
/**
 *
 * @author truon
 */
public class NhanVien implements Serializable {
     public String MaNV;
     public String HoTen;
     public double Tuoi;

    public NhanVien(String MaNV, String HoTen, double Tuoi, String Email, double Luong) {
        this.MaNV = MaNV;
        this.HoTen = HoTen;
        this.Tuoi = Tuoi;
        this.Email = Email;
        this.Luong = Luong;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public void setTuoi(double Tuoi) {
        this.Tuoi = Tuoi;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setLuong(double Luong) {
        this.Luong = Luong;
    }

    public String getMaNV() {
        return MaNV;
    }

    public String getHoTen() {
        return HoTen;
    }

    public double getTuoi() {
        return Tuoi;
    }

    public String getEmail() {
        return Email;
    }

    public double getLuong() {
        return Luong;
    }
     public String Email;
     public double Luong;
     
    
    


}
