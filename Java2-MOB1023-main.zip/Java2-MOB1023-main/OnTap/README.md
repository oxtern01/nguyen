Bài ôn tập, sử dụng generics và tạo ra class SwingHelper gồm nhiều tiện ích để hỗ trợ làm swing và thích ứng với bất kỳ model nào nhờ abstract class DAO và interface Exportable
Đồng thời sử dụng Enum SHelper để switch case trạng thái một cách rõ ràng hơn

Đề ở [đây](https://github.com/SilencedFrost/Java2-MOB1023/blob/main/OnTap/src/Resources/%C4%90%E1%BB%81%20%C3%B4n%20t%E1%BA%ADp%20thi%20.pdf)
