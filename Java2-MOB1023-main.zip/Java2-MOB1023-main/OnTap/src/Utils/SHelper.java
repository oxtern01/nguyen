/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

/**
 *
 * @author thnrg
 */
public enum SHelper {
    TRUE, EMPTY_ERROR, NAN_ERROR, NEGATIVE_NUMBER_ERROR, ALREADY_EXIST_ERROR, NOT_FOUND_ERROR
}
