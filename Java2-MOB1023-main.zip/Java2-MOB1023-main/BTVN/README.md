Đây là bài thầy Tuấn Lê gửi về nhà để sinh viên khám phá thêm

Đề bài: Copy một file gốc thành nhiều file, với mỗi file một tên theo người dùng chọn

Ứng dụng: Danh sách chấm công, tạo một file gốc, và một danh sách nhân viên, từ đó có thể tạo ra nhiều danh sách chấm công cho từng nhân viên

Yêu cầu: Sử dụng windows batch (.bat)